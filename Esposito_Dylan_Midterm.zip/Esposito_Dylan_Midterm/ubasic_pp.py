#!/usr/bin/env python
# Cuppa1 pretty printer

from sys import stdin
from ubasic_interp_gram import parser
from ubasic_lex import lexer
from ubasic_state import state
from w1 import walk as a5_walk
from w2 import walk as a5_walk2


def pp(input_stream = None):

    # if no input stream was given read from stdin
    if not input_stream:
        input_stream = stdin.read()

    # initialize the state object and indent level
    state.initialize()
    #init_indent_level()

    # build the AST
    parser.parse(input_stream, lexer=lexer)

    # walk the AST
    a5_walk(state.AST)
    code = a5_walk2(state.AST)

    # output the pretty printed code
    #print(code)

if __name__ == "__main__":
    # execute only if run as a script
    pp()
