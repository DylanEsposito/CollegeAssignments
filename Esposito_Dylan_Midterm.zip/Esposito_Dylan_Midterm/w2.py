from ubasic_state import state
from grammar_stuff import assert_match
import sys

def seq(node):
    
    (SEQ, s1, s2) = node
    assert_match(SEQ, 'seq')
    
    #Walk through left and right sides
    stmt = walk(s1)
    list = walk(s2)
    
    #set stmt to str as error protection
    code = str(stmt) + list 
    return code

#Similar in structure as seq
def value_list(node):
    (VAL, s1, s2) = node
    assert_match(VAL, 'val_list')
    
    stmt = walk(s1)
    list = walk(s2)
    code = str(stmt) + " " + list
    return code

def nil(node):
    (NIL,) = node
    assert_match(NIL, 'nil')
    code = ''   
    return code

def end_stmt(node):
    (END,) = node
    assert_match(END, 'Endstmt')
    code = '\n'
    #Warn user that they are trying to call system exit
    print("Input of end, calling system exit")
    #exit the system
    sys.exit()
    return code

def assign_stmt(node):
    (ASSIGN, name, exp) = node
    assert_match(ASSIGN, 'Assignstmt')
    
    #walk given value
    exp_code = walk(exp)
    
    #enter or update value into symbol table
    state.symbol_table[name] = ('INTEGER', exp_code)
    
    #new line and check to see if name is used
    code = exp_code + '\n'
    if not state.symbol_table[name]:
        code = ' // *** '+ name + ' is not used ***'
    #return code
    return code

def in_stmt(node):
    
    (INPUT, name) = node
    assert_match(INPUT, 'Instmt')
    
    #check done to make sure value isn't a string, if so request
    #made for user to reenter input
    while True:
        inCode = input(" ")
        try:
            inCode = int(inCode)
            break
        except ValueError:
            print("Your input can only be an integer, try again\n")
            
        
    #place value into the symbol table
    state.symbol_table[name] = ('INTEGER', str(inCode))
    
    #create new line
    code = str(inCode) + '\n'
    
    if not state.symbol_table[name]:
        code += ' // *** '+ name + ' is not used ***'
    
    #return code
    return code


def if_stmt(node):
    #check done to see if there is no else statement
    try:
        (IF, exp, stmt_list, (Nil,), endif) = node
        #if((opt_else) == 'endif')
        assert_match(IF, 'Ifstmt')
        assert_match(Nil, 'nil')
        #print("Only one if statement")
    #otherwise there is an else statement
    except ValueError: # pattern didn't match
        (IF, exp, stmt_list, opt_else, endif) = node
        assert_match(IF, 'Ifstmt')
        
        #Walk through and see what condition is
        exp_code = walk(exp)
        #set code equal to condition as a means to activate variable
        code = exp_code 
        #check if condition is true, walks through the list and code updates itself. Repeats if statement is false
        if(exp_code == True):
            stmt_walk = walk(stmt_list)
            code = stmt_walk
        else:
            stmt_walk = walk(opt_else)
            code = stmt_walk
        #convert code to str and create new line
        code = str(code) + '\n'
        return code
    
    #Similar as if/else procedure, except there is no else statement.
    exp_code = walk(exp)
    code = exp_code 
    if(exp_code == True):
        stmt_walk = walk(stmt_list)
        code = stmt_walk
    code = str(code) + '\n'
    return code

def while_stmt(node):
    (WHILE, exp, stmt_list, endwhile) = node
    assert_match(WHILE, 'Whilestmt')
    
    #First we grab the condition to see if it can be used in the
    exp_code = walk(exp)
    code = exp_code
    #Next we run a while loop that continues as long 
    #as the statement is true
    while exp_code == True:
        exp_code = walk(exp)
        stmt_walk = walk(stmt_list)
    #set code to new line since we do not need to return anything
    code = '\n'
    return code

def for_stmt(node):
    #Check if there is a value to step by given to us
    try:
        (FOR, name, start, end, (Nil,), stmt_list, nxName) = node
        assert_match(FOR, 'Forstmt')
        assert_match(Nil, 'nil')                
    #Otherwise value to step by given to us
    except ValueError: 
        (FOR, name, start, end, step, stmt_list, nxName) = node
        assert_match(FOR, 'Forstmt')
        
        #Walk to find values of starter, endPoint and stebyBY
        starter  = walk(start)
        endPoint = walk(end)
        stepBy = walk(step)
        
        #Convert stepby, newVal and endPoint to integers
        stepBy = int(stepBy)   
        i = int(starter)
        endPoint = int(endPoint)
       
        #Create forloop that updates newVal by a certain amount until we reach the endpoint.
        for i in range (int(starter), endPoint, stepBy):
            #This is done irregardless of whether or not the given variable is being updated by the stepBy.
            #If it is not being updated by the amount we step then the value will update itself when we
            #through the stmt_list
            state.symbol_table[name] = ('INTEGER', i)
            listS = walk(stmt_list)
        #set code to the string of newVal and then we return it
        code = str(i)
        return code
    #Same process as before where we walk all the values and convert them to integers.
    starter  = walk(start)
    endPoint = walk(end) 
    i = int(starter)
    endPoint = int(endPoint)
    stepBy = 1
    
    #For loop structure is the same except we update newVal only by one
    for i in range(int(starter), endPoint):
        i+=stepBy
        #This is done irregardless of whether or not the given variable is being updated by the stepBy.
        #If it is not being updated by the amount we step then the value will update itself when we
        #through the stmt_list
        state.symbol_table[name] = ('INTEGER', i)
        stmt_walk = walk(stmt_list)
    code = str(i)
    return code

def print_stmt(node):
    (PRINT, value, value_list) = node
    assert_match(PRINT, 'Printstmt')      
    #Call walk on the first value
    value_walk = walk(value)
    code = str(value_walk)
    #Walk thourgh list of values
    v_l = walk(value_list)
    #append all the values gathered in the list to code
    code+= " " + str(v_l)
    print(code)
    return code

def binop_exp(node):
    
    (OP, c1, c2) = node
    if OP not in ['+', '-', '*', '/', '==', '<=']:
        raise ValueError("pattern match failed on " + OP)
    
    #Walk thorugh left side and right side
    lcode = walk(c1)
    rcode = walk(c2)
    i = 0
    t = 0
    
    #Check to see if given variable is an int
    #If not then we access its integer value from the symbol_table 
    try: 
        i = int(lcode)
    except ValueError: 
        #print("This is the value of c2" + str(c1))
        #print(state.symbol_table[lcode])
        z = state.symbol_table[lcode] 
        i = int(z[1])
        #print("The value of z is" + str(z))
        #print("The value of i is " + str(i))
        
    #Same thing as we check on left side
    try:
        t = int(rcode)
    except ValueError:
        #print("This is the value of c2" + c2)
        z = state.symbol_table[c2[1]] 
        #print("The value of z is")
        t = int(z[1])
        #print("The value of i is " + str(t))
    #Create integer of u that will be the result of the 
    #basic calculations we perform
    u = 0
    #Code created outside so we can return it
    code = str(u)
    if OP == '+':      
        u = int(i) + int(t)
        code = str(u)
    elif OP == '-':
        u = int(i) - int(t)
        code = str(u)
    elif OP == '*':
        u = int(i) * int(t)
        code = str(u)
    elif OP == '/':
        u = int(i)/int(t)
        code = str(u)
    elif OP == '==':
        if int(i) == int(t):
            u = True
        else:
            u = False
        code = u
    elif OP == '<=':
        if int(i) <= int(t):
            u = True
        else:
            u = False
        code = u
    #Return code
    return code

def integer_value(node):
    
    (INTEGER, value) = node
    assert_match(INTEGER, 'INTEGER')
   
    code = str(value)
    return code

#########################################################################
def id_value(node):
    
    (ID, name) = node
    assert_match(ID, 'ID')
    
    #print("This is the " + str(name))
    if name in state.symbol_table:
        z = state.symbol_table[name]
        code = int(z[1])
        return code
    else:
        state.symbol_table[name] = ('INTEGER', 1)
        z = state.symbol_table[name]
        code = int(z[1])
        return code

def string_value(node):
    (STRING, name) = node
    assert_match(STRING, 'STRING')
    
    code = str(name)
    return code

#########################################################################
def uminus_exp(node):
    
    (UMINUS, e) = node
    assert_match(UMINUS, 'uminus')
    
    code = walk(e)

    return '-' + code

#########################################################################
def not_exp(node):
    
    (NOT, e) = node
    assert_match(NOT, 'not')
    
    code = walk(e)

    return 'not ' + code

#########################################################################
def paren_exp(node):
    
    (PAREN, exp) = node
    assert_match(PAREN, 'paren')
    
    exp_code = walk(exp)

    return '(' + exp_code + ')'

def walk(node):
    node_type = node[0]
    if node_type in dispatch_dict:
        node_function = dispatch_dict[node_type]
        return node_function(node)
    
    else:
        raise ValueError("walk: unknown tree node type: " + node_type)
        
dispatch_dict = {
    'seq'     : seq,
    'val_list' : value_list,
    'nil'     : nil,
    'Instmt'  : in_stmt,
    'Printstmt' : print_stmt,
    'Assignstmt' : assign_stmt,
    'Endstmt' : end_stmt,
    'Whilestmt' : while_stmt,
    'Forstmt' : for_stmt,
    'Ifstmt'  : if_stmt,
    'INTEGER' : integer_value,
    'ID'      : id_value,
    'STRING'  : string_value,
    'uminus'  : uminus_exp,
    'not'     : not_exp,
    'paren'   : paren_exp,
    '+'       : binop_exp,
    '-'       : binop_exp,
    '*'       : binop_exp,
    '/'       : binop_exp,
    '=='      : binop_exp,
    '<='      : binop_exp

}