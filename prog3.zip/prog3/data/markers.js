var markers = [
	["CENTER", 42.37, -71.12],
	["starbucks - cafe", 42.3237, -71.1624],
	["starbucks - cafe", 42.303, -71.152],
	["starbucks - cafe", 42.3387, -71.1367],
	["starbucks - cafe", 42.3587, -71.1543],
	["starbucks - cafe", 42.3337, -71.1187],
	["starbucks - cafe", 42.3426, -71.1216],
	["starbucks - cafe", 42.3386, -71.1062],
	["starbucks - cafe", 42.3377, -71.1047],
	["starbucks - cafe", 42.3442, -71.1014],
	["starbucks coffee - cafe", 42.3467, -71.0876],
	["starbucks coffee - cafe", 42.3486, -71.096],
	["starbucks coffee - cafe", 42.3483, -71.087],
	["starbucks - cafe", 42.3494, -71.1031],
	["starbucks (smg) - cafe", 42.3495, -71.0999],
	["starbucks coffee- bu barnes and noble - cafe", 42.349, -71.0952],
	["starbucks - cafe", 42.3507, -71.1143],
	["starbucks - cafe", 42.3724, -71.1194],
	["starbucks - cafe", 42.363, -71.0857],
	["starbucks - cafe", 42.3638, -71.0878],
	["starbucks - cafe", 42.3656, -71.1037],
	["starbucks - cafe", 42.3887, -71.1424],
	["starbucks - cafe", 42.3823, -71.1199],
	["starbucks - cafe", 42.3861, -71.1142],
	["starbucks - cafe", 42.3957, -71.1223],
	["starbucks coffee - cafe", 42.4148, -71.151],
	["starbucks - cafe", 42.3485, -71.0764],
	["starbucks - cafe", 42.3564, -71.0693],
	["starbucks - cafe", 42.3459, -71.0437],
	["starbucks - cafe", 42.3532, -71.0577],
	["starbucks - cafe", 42.3556, -71.0611],
	["starbucks - cafe", 42.3577, -71.0592],
	["starbucks - cafe", 42.361, -71.0665],
	["starbucks - cafe", 42.3633, -71.0247],
	["starbucks - cafe", 42.3622, -71.0197],
	["starbucks coffee - cafe", 42.3702, -71.019],
