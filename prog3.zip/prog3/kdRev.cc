#include "KDTree.h"
#include <math.h>
#include <iostream>

KDNode::KDNode(double lat, double lon, const char *desc, int argdepth)
{
        left = NULL;
        right = NULL;
        description = desc;
        latitude = lat;
        longitude = lon;
        depth = argdepth;
}

KDNode::~KDNode()
{

}

double KDNode::distance(double lat, double lon)
{
        double param = M_PI / 180.0; // required for conversion from degrees to radians
        double rad = 3956.0; // radius of earth in miles
        double d_lat = (lat - latitude) * param;
        double d_lon = (lon - longitude) * param;
        double dist = sin(d_lat/2) * sin(d_lat/2) + cos(latitude*param) * cos(lat*param) * sin(d_lon/2) * sin(d_lon/2);
        dist = 2.0 * atan2(sqrt(dist), sqrt(1-dist));
        return rad * dist;
}

KDTree::KDTree()
{
        root = NULL;
        size = 0;
}

KDTree::~KDTree()
{
        // TOD0
        destroy(root);
        root = NULL;
}

void KDTree::destroy(KDNode *p)
{
        //TODO
        if (p) {
                //If so I recursivelly call to the left
                destroy(p->left);
                //Eles I recursievelly call to the right
                destroy(p->right);
                //Otherwise I detele the root if I reached a null Node
                delete p;
                size--;
        }
}


void KDTree::insert(double lat, double lon, const char *desc)
{
        // TODO
        int depth = 0;
        insertHelper(&root,lat,lon,desc,depth);
}

void KDTree::insertHelper(KDNode **p, double lat, double lon, const char *desc, int depth)
{
        std::cout << "insert depth: " << depth << "\n";
        //NEED TO ORGANIZE AROUND CUTTING DIMENSION
        //if(cuttingDim = 1)
        //if((p)->lat < lat2)
        //insert2(&((p)->right), lat, lon, desc, 2)
        //else:
        ////insert2(&((p)->right), lat, lon, desc, 2)
        //elseif(cuttingDim = 2)
        //if((p)->lon < lon2)
        //insert2(&((p)->right), lat, lon, desc, 1)
        //else:
        //insert2(&((p)->left), lat, lon, desc, 1)

        if (!*p)
        {
                std::cout << "creation depth: " << depth << "\n";
                int creationDepth = depth;
                *p = new KDNode(lat,lon,desc, creationDepth);
                std::cout << "P depth: " << (*p)->depth << "\n";
                size++;
        }
        else
        {
                if (depth % 2 == 1) 
                {
                        //if the lat2 is greater than, go right
                         //if the lon2 is greater than we go right
                        if((*p)->longitude < lon) {
                                depth++;
                                insertHelper(&(*p)->right, lat, lon, desc, depth);
                        }
                        //if the lon2 is less than we go left
                        if((*p)->longitude >= lon) {
                                depth++;
                                insertHelper(&(*p)->left, lat, lon, desc, depth);
                        }
                }
                else
                {
                       if((*p)->latitude < lat) {
                                depth++;
                                insertHelper(&(*p)->right, lat, lon, desc, depth);
                        }
                        //if the lat2 less than, go left
                        if((*p)->latitude >= lat) {
                                depth++;
                                insertHelper(&(*p)->left, lat, lon, desc, depth);
                        }
                }
        }
}

unsigned int KDTree::printNeighbors(double lat, double lon, double rad, const char *filter)
{
        // TODO

        // Taken from llist.cc
        int count = 0;
        std::cout << "var markers = [\n";
        std::cout << "\t[\"" << "CENTER" << "\", " << lat << ", " << lon << "],\n";

        return printNeighborsHelper(root, lat, lon, rad, filter, 0, count);
}

unsigned int KDTree::printNeighborsHelper(KDNode *p, double lat, double lon, double rad, const char *filter, int depth, int count) {
        if (p) 
        {
                int nodeDepth = p->depth;
                //std::cout << "in loop";
                // checkk if p falls within the radius, meaning distance is less than radius
                // check if p out of bounds is to the left or to the right (bounds is the depth we are at)
                //cout the value
                //filter is the string we are searching for.
                std::cout << "count: " << count << "\n";
                std::cout << "p lat, long: " << p->latitude << "," << p->longitude << "\n";
                std::cout << p->distance(lat,lon) << " <= to " << rad << ": ";
                std::cout << "current depth: " << nodeDepth << "\n";
                //std::cout << "place: " << p->description << "\n";

                if (p->distance(lat, lon) <= rad) {
                        std::cout << "yes" << "\n";
                        // double traversal
                        count++;
                        nodeDepth++;
                        std::cout << "\t[\"" << p->description << "\", " << p->latitude << ", " << p->longitude << "],\n";
                        return printNeighborsHelper(p->left,lat,lon,rad,filter,nodeDepth,count);
                        return printNeighborsHelper(p->right,lat,lon,rad,filter,nodeDepth,count);
                }
                else
                {
                        std::cout << "no" << "\n";
                        if (nodeDepth % 2 == 1)
                        {
                                std::cout << "depth % 2 == 1 for depth:" << nodeDepth << "\n";
                                //if p.longitude < lon go on left subtree
                                // if p.longitude > lon go on right subtree
                                if(p->longitude <= lon)
                                {
                                        nodeDepth++;
                                        return printNeighborsHelper(p->right,lat,lon,rad,filter,nodeDepth,count);
                                }
                                // if p.latitude > lat go on right subtree
                                else
                                {
                                        nodeDepth++;
                                        return printNeighborsHelper(p->left,lat,lon,rad,filter,nodeDepth,count);
                                }
                        }
                        else
                        {
                                std::cout << "depth % 2 == 0 for depth:" << nodeDepth << "\n";
                                //if p.latitude < lat go on left subtree
                                if(p->latitude <= lat)
                                {
                                        nodeDepth++;
                                        return printNeighborsHelper(p->right,lat,lon,rad,filter,nodeDepth,count);
                                }
                                // if p.latitude > lat go on right subtree
                                else
                                {
                                        nodeDepth++;
                                        return printNeighborsHelper(p->left,lat,lon,rad,filter,nodeDepth,count);
                                }
                        }
                }
        }

        return count;
}

unsigned int KDTree::getSize() {
        // TODO
        return size;
}
