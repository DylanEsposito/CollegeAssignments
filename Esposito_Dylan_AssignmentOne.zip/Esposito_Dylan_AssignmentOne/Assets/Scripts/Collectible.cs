﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Collectible : MonoBehaviour {


	// Update is called once per frame
	void Update () {

        transform.Rotate(new Vector3(5,45,97) * Time.deltaTime );
	}
}
