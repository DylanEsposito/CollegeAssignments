﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class playerController : MonoBehaviour {

    /// <summary>
    /// Reference to the player rigid body
    /// </summary>
    private Rigidbody _player_rb;

    /// <summary>
    /// Reference to the player's camera
    /// </summary>
    public Camera _player_cam;

    public Text _score_text;

    /// <summary>
    /// Control speed
    /// </summary>
    public float _speed = 200f;

    //create text object for game over text
    public Text _game_Over_Text;

    /*
     * Create score variable that is initally not assigned a value. Upon building the game, the score will automatically
     * be assigned to zero. However since we declare score as static, then the value assigned to score upon reaching the
     * end of the scene it will be carried over into the next level.
    */
    public static float _score;

    /// <summary>
    /// Follow camera offset
    /// </summary>
    Vector3 _offset;

    /// <summary>
    /// Initialize the scene.
    /// Stores camera offset positioning
    /// </summary>
    void Start () {

        //Assign the player a rigid boy attribute
        _player_rb = GetComponent<Rigidbody>();

        //Offset camera to the position of the player
         _offset = _player_cam.transform.position - _player_rb.transform.position;

        //Initalize text displaying the word "Score" as well as the value store in score
        _score_text.text = "Score: " + _score;
        //Set the text assigned to the Game Over text to zero
        _game_Over_Text.text = " ";
    }



    /// <summary>
    /// Movement control for the player and camera.
    /// Updates every frame
    /// </summary>
    void Update () {

        //Allows us to move both vertically and horizontally
        float moveVertical = Input.GetAxis("Vertical");
        float moveHorizontal = Input.GetAxis("Horizontal");

        //Allows us 
        Vector3 movementVec = new Vector3(moveHorizontal, 0, moveVertical);

        //Allows us to add momentum to player object. 
        _player_rb.AddForce(movementVec * _speed * Time.deltaTime);

        //Allows us to continually update the players position in every frame.
        _player_cam.transform.position = _player_rb.position + _offset;


    }

    private void OnTriggerEnter(Collider other)
    {
        //Check if object is tagged as a collectible
        if (other.CompareTag("Collectible"))
        {
            //Update the value stored in "_score" by one
            _score = _score + 1;
            //Update the value stored in the _score_text variable
            _score_text.text = "Score: " + _score.ToString();
            //tell debugger that a collectible has been retrieved
            Debug.Log("Entered Collectible");
            //set the collectible that we have collided with to false.
            other.gameObject.SetActive(false);

        }
        //checks if the object is tagged as Finish, meaning we reached the end of the maze
        else if (other.CompareTag("Finish"))
        {
            //Set the game over text to active
            _game_Over_Text.gameObject.SetActive(true);

            //after reaching the finish trigger, Unity will check if there is another scene coming up. If so it will load that scene in.
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);

            //Set the game over text to display your score
            _game_Over_Text.text = "Congrats you won! Your final score is " + _score.ToString();
        }

        //when picking up trigger, 
    }



}
